# IVotePropose

## 1. Interface Description
   Interface to be implemented for voting contract

## 2. Method Description

### 2.1. Methods to be called after approved
     
```javascript
    /// @dev Methods to be called after approved
    function run() external;
```
